package dev.emjey.testTask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
